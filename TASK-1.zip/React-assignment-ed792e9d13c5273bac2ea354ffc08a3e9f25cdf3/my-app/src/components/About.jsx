// src/components/About.js
import React from 'react';

const About = () => {
  const style = {
    textAlign: 'center',
  };

  return <h2 style={style}>About Page</h2>;
};

export default About;
