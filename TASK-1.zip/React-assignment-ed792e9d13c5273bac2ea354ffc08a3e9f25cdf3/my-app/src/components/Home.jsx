// src/components/Home.js
import React from 'react';

const Home = () => {
  const style = {
    textAlign: 'center',
  };

  return <h2 style={style}>Home Page</h2>;
};

export default Home;
