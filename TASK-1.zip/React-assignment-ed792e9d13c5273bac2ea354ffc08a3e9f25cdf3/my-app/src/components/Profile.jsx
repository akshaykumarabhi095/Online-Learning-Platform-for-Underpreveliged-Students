// src/components/Profile.js
import React from 'react';

const Profile = () => {
  const style = {
    textAlign: 'center',
  };

  return <h3 style={style}>Profile Page</h3>;
};

export default Profile;
