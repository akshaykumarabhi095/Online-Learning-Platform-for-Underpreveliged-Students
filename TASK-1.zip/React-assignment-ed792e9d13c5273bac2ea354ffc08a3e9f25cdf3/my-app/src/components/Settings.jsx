// src/components/Settings.js
import React from 'react';

const Settings = () => {
  const style = {
    textAlign: 'center',
  };

  return <h3 style={style}>Settings Page</h3>;
};

export default Settings;
